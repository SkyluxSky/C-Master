#include <stdio.h>
#include <stdlib.h>

// C Memory Addresses for storing information
//How to access memory address.

int main()
{
    int age = 30;//value 30 gets stored in memory(RAM), access information by accessing the name of the variable
    double gpa = 3.4;
    char grade = 'A';

    //prints variables and their corresponding addresses.
    printf("age: %p\ngpa: %p\ngrade: %p", &age, &gpa, &grade);// %p = pointer for accessing memory addresses





    return 0;
}
