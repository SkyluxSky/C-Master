#include <stdio.h>
#include <stdlib.h>

int main()
{
    char line[255];
    FILE * fpointer = fopen("employees.txt", "r");//r reads a file

    fgets(line, 255, fpointer);

    printf("%s", line);
    printf("%s", line);
    printf("%s", line);

    fclose(fpointer);

    return 0;
}
