#include <stdio.h>
#include <stdlib.h>
// creating, writing and appending files


int main()
{
    FILE * fpointer = fopen("employees.txt", "a");//fopen opens a file for us
    /*r stands for read, w stands for write or save over an existing file, a stands for append from file  */
    /*fprintf(fpointer, "Jim, Salesman\nPam, Receptionist\nOscar, Accounting\n");*///fprintf writes information to a file
    fprintf(fpointer, "\nKelly, Customer Service");//adds new line
    fclose(fpointer);//closes file via memory pointer

    return 0;
}
