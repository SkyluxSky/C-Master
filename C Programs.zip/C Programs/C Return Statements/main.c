#include <stdio.h>
#include <stdlib.h>
/* returns allow functions to be called to give back specific information. If you want to define a function, write the function above the main method.
What kind of data you want C to return. One type is void which tells C not to return any information. Returning a double   */

/* double cube(double num);
Prototyping code allows you to put a function bellow the function that is calling it only if you state the first line of the function before the primary function*/

double cube(double num){
    double result = num * num * num; // Double tells C what kind of data type you want C to read
    return result;
}


int main()
{
    printf("Answer: %f", cube(7.0));// We can call a function that contains a number
    return 0;
}


/*double cube(double num){
    double result = num * num * num; // Double tells C what kind of data type you want C to read
    return result;
}*/
