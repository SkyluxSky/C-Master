#include <stdio.h>
#include <stdlib.h>

/* If statements help our programs make decisions */

int max(int num1, int num2, int num3){//This function will take two integers one being num1 and  the other being num2
    int result;
    if(num1 >= num2 && num1 >= num3){//if inside parentheses is true it will read code within if statement, if false code will skip over. && is a logical operator for and (used to create two conditions)
        result = num1;
    } else if(num2 >= num1 && num2 >= num3) { // Else if can check for another condition
        result = num2;
    } else {
        result = num3;// if non of the conditions are true else statement will enable

    }

/* For if statements we specify a condition if true we execute one line if false we execute the else statement*/

}

int main()
{
    /*printf("%d", max(400, 10, 110));*/
    /* or function for if statements (||) will allow us to check two conditions but the whole will be true if only one requirement is true
    ! is a negation operator which prints false */
    if(!(3 == 2 || 2 == 5)){
        printf("True");
    } else {
        printf("False");
    }


    return 0;
}
