#include <stdio.h>
#include <stdlib.h>

//A Function is a collection of code that performs a specific task

int main()//Int main to return is a function, a main function is the function that runs when we start our program
{
    printf("Top\n");
    sayHi("Cam", 23);// Calling a created function
    sayHi("Mike", 55);
    sayHi("Tom", 70);
    printf("\nBottom");

    return 0;
}

//1st tell C the return type of the function
// void means no information will be returned
// Name function according to what it does

void sayHi(char name[], int age)
{
    printf("Hello %s, you are %d\n", name, age);

}
//Values that we give to a function is called a parameter
