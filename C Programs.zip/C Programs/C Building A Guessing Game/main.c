#include <stdio.h>
#include <stdlib.h>

int main()
{
    int secretNumber = 5;//what the number is
    int guess;// the container for the users guess
    int guessCount = 0;//how many times they guess the number
    int guessLimit = 3;//how many times they can guess the number
    int outOfGuesses = 0;//tell us if user is out of guesses

    while(guess != secretNumber && outOfGuesses == 0){
            if(guessCount < guessLimit){
            printf("Enter a number: ");//code goes within If statement
            scanf("%d", &guess);
            guessCount++;
            } else {
                outOfGuesses = 1;//assign a value of 1
            }
    }
    if(outOfGuesses == 1){//if out of guesses is 1
        printf("Out of guesses");
    } else {
        printf("You Win!");
    }


    return 0;
}
