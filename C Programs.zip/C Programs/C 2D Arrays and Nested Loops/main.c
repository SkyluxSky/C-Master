#include <stdio.h>
#include <stdlib.h>
//2Dimensional or multidimensional array is an array where all the elements are Arrays themselves.
//Nested Loops a loop inside a loop.

int main()
{
    int nums[3][2] = {//2dimensional Arrays need two boxes to mark down for number of Arrays and how many numbers are within each Array.
                   {1, 2},//index 0 Array
                   {3, 4},//index 1 Array
                   {5, 6}//index 2 Array
                   };

    int i, j;//declares two variables

    for(i = 0; i < 3; i++){//loops 3 times
        for(j = 0; j < 2; j++){//loops for elements within arrays
                printf("%d, ", nums[i][j]);
        }
    printf("\n");
    }
    return 0;
}
