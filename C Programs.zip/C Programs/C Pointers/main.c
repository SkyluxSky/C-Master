#include <stdio.h>
#include <stdlib.h>
//Pointers Tutorial
//integer = whole number, double = decimal number, char = character
//A Pointer = Memory Address inside the RAM

//when I create a pointer variable inside of the pointer variable I am going to include the memory address of another variable withing our program

int main()
{
    int age = 30;
    int * pAge = &age;
    double gpa = 3.4;
    double * pGpa = &gpa;
    char grade = 'A';
    char * pGrade = &grade;


    printf("age's memory address: %p\n", &age);//&age is the pointer
    return 0;
}
