#include <stdio.h>
#include <stdlib.h>


/* structs - are data structures where we can store multiple data types (int, double, str)

Used for modeling real world entities*/

struct Student{
    char name[50];
    char major[50];
    int age;
    double gpa;

};


int main()
{
    struct Student student1;//created a container that can store different data types
    student1.age = 22;
    student1.gpa = 3.2;
    strcpy( student1.name, "Jim");// how to set a string in a struct
    strcpy( student1.major, "Business");

    struct Student student2;//created a container that can store different data types
    student2.age = 20;
    student2.gpa = 3.8;
    strcpy( student2.name, "Pam");// how to set a string in a struct
    strcpy( student2.major, "Art");

    printf("%s", student1.name);
    printf("\n%s", student1.major);
    printf("\n%f", student2.gpa);




    return 0;
}
