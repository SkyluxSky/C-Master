#include <stdio.h>
#include <stdlib.h>

/* While loops can continuously run a block of code until a condition is false*/

int main(){

    int index = 1;
    while(index <= 5){//specify condition in parentheses, as long as the condition is true it will keep looping
        printf("%d\n", index);
        index++;// ++ adds one to the value each loop
    }

    do {//do while loops print out the code before reading the condition.
        printf("%d\n", index);
        index++;// ++ adds one to the value each loop
    } while(index <= 5);

    return 0;
}
