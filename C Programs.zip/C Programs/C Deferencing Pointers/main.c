#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age = 30;
    int * pAge = &age;//pointer storing memory address of 30

    printf("Pointer Memory Address: %p\n", pAge); //using * dereferences a pointer turns memory address into integer
    printf("Value That is Stored  in Memory Address: %d\n", *pAge);
    printf("%d", *&age);

    return 0;
}
