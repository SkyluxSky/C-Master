#include <stdio.h>
#include <stdlib.h>

/* Switch Statement  - Compares one value to a bunch of different/other values*/

int main(){

    char grade = 'A';

    switch(grade){//Basic structure for switch statements
        case 'A' :// case stores results for an identified variable
            printf("You did great!");
            break; // break; ends the switch statement
        case 'B' :
            printf("You did alright!");
            break;
        case 'C' :
            printf("You did poorly!");
            break;
        case 'D' :
            printf("You did very bad!");
            break;
        case 'F' :
            printf("You failed!");
            break;
        case 'E' :
            printf("Your too slow!");
            break;
        default :// default is an else statement, activates when non of the conditions are met
            printf("Invalid grade, please try again");

    }


    return 0;
}
